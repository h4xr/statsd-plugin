**StatsD Plugin**

Package provides a library to build new plugins for StatsD

Plugins built here follows a python class based implementation and are executed in parallel on the system to collect and report the metrics to the StatsD server.

**Note**: The project is currently in early stages of development and may be unstable for production use.


